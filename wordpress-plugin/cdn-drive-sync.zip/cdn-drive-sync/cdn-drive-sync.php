<?php
/**
 * Plugin Name: CDN Drive Sync
 * Description: Syncs WordPress media files and generated image sizes to CDN Drive, then rewrites media URLs to the BunnyCDN hostname.
 * Version: 1.0.0
 * Author: CDN Drive
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

final class CDN_Drive_Sync
{
    private const OPTION = 'cdn_drive_sync_options';

    public static function boot(): void
    {
        add_action('admin_menu', [self::class, 'adminMenu']);
        add_action('admin_init', [self::class, 'registerSettings']);
        add_action('admin_post_cdn_drive_sync_attachment', [self::class, 'handleManualSync']);
        add_action('add_attachment', [self::class, 'syncAttachmentAdded']);
        add_filter('wp_update_attachment_metadata', [self::class, 'syncAttachmentMetadata'], 20, 2);
        add_action('delete_attachment', [self::class, 'deleteAttachment']);
        add_filter('wp_get_attachment_url', [self::class, 'filterAttachmentUrl'], 20, 2);
        add_filter('wp_calculate_image_srcset', [self::class, 'filterSrcset'], 20);
    }

    public static function adminMenu(): void
    {
        add_options_page('CDN Drive Sync', 'CDN Drive Sync', 'manage_options', 'cdn-drive-sync', [self::class, 'settingsPage']);
    }

    public static function registerSettings(): void
    {
        register_setting('cdn_drive_sync', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [self::class, 'sanitizeOptions'],
            'default' => self::defaults(),
        ]);
    }

    public static function sanitizeOptions($value): array
    {
        $value = is_array($value) ? $value : [];
        return [
            'api_base' => esc_url_raw(trim((string)($value['api_base'] ?? ''))),
            'api_token' => sanitize_text_field((string)($value['api_token'] ?? '')),
            'cdn_base_url' => esc_url_raw(trim((string)($value['cdn_base_url'] ?? ''))),
            'path_prefix' => self::cleanPrefix((string)($value['path_prefix'] ?? 'wp')),
            'replace_urls' => empty($value['replace_urls']) ? '0' : '1',
            'auto_sync' => empty($value['auto_sync']) ? '0' : '1',
        ];
    }

    public static function settingsPage(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $options = self::options();
        $notice = get_transient('cdn_drive_sync_notice');
        if ($notice) {
            delete_transient('cdn_drive_sync_notice');
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html($notice) . '</p></div>';
        }
        ?>
        <div class="wrap">
            <h1>CDN Drive Sync</h1>
            <form method="post" action="options.php">
                <?php settings_fields('cdn_drive_sync'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="cdn_drive_api_base">CDN Drive External API</label></th>
                        <td>
                            <input id="cdn_drive_api_base" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[api_base]" value="<?php echo esc_attr($options['api_base']); ?>" placeholder="https://example.com/api/external">
                            <p class="description">CDN Drive 管理画面に表示される WordPress 連携 Endpoint を入力します。</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cdn_drive_api_token">API Token</label></th>
                        <td>
                            <input id="cdn_drive_api_token" class="regular-text" type="password" name="<?php echo esc_attr(self::OPTION); ?>[api_token]" value="<?php echo esc_attr($options['api_token']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cdn_drive_cdn_base">CDN Base URL</label></th>
                        <td>
                            <input id="cdn_drive_cdn_base" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[cdn_base_url]" value="<?php echo esc_attr($options['cdn_base_url']); ?>" placeholder="https://cdn.example.com">
                            <p class="description">WordPress が出力するメディア URL の置換先です。</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cdn_drive_path_prefix">Remote Path Prefix</label></th>
                        <td>
                            <input id="cdn_drive_path_prefix" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[path_prefix]" value="<?php echo esc_attr($options['path_prefix']); ?>" placeholder="wp">
                            <p class="description">通常は <code>wp</code> のままで使います。CDN Drive には <code>wp/2026/07/image.jpg</code> のように保存されます。</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Behavior</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[auto_sync]" value="1" <?php checked($options['auto_sync'], '1'); ?>> Upload/Regenerate 時に自動同期する</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[replace_urls]" value="1" <?php checked($options['replace_urls'], '1'); ?>> WordPress の画像 URL と srcset を CDN URL に置換する</label>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>

            <hr>
            <h2>Manual Sync</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('cdn_drive_sync_attachment'); ?>
                <input type="hidden" name="action" value="cdn_drive_sync_attachment">
                <label for="cdn_drive_attachment_id">Attachment ID</label>
                <input id="cdn_drive_attachment_id" name="attachment_id" type="number" min="1">
                <?php submit_button('Sync Attachment', 'secondary', 'submit', false); ?>
            </form>
        </div>
        <?php
    }

    public static function syncAttachmentMetadata($metadata, int $attachmentId)
    {
        $options = self::options();
        if ($options['auto_sync'] !== '1') {
            return $metadata;
        }
        self::syncAttachment($attachmentId);
        return $metadata;
    }

    public static function syncAttachmentAdded(int $attachmentId): void
    {
        $options = self::options();
        if ($options['auto_sync'] === '1') {
            self::syncAttachment($attachmentId);
        }
    }

    public static function handleManualSync(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Forbidden', 403);
        }
        check_admin_referer('cdn_drive_sync_attachment');
        $attachmentId = absint($_POST['attachment_id'] ?? 0);
        if ($attachmentId <= 0) {
            set_transient('cdn_drive_sync_notice', 'Attachment ID が正しくありません。', 30);
            wp_safe_redirect(admin_url('options-general.php?page=cdn-drive-sync'));
            exit;
        }
        $result = self::syncAttachment($attachmentId);
        $message = is_wp_error($result) ? $result->get_error_message() : 'Attachment synced: ' . (string)$attachmentId;
        set_transient('cdn_drive_sync_notice', $message, 30);
        wp_safe_redirect(admin_url('options-general.php?page=cdn-drive-sync'));
        exit;
    }

    public static function deleteAttachment(int $attachmentId): void
    {
        $paths = [];
        foreach (self::attachmentFiles($attachmentId) as $file) {
            $paths[] = $file['remote'];
        }
        if ($paths) {
            self::requestJson('/delete', ['paths' => array_values(array_unique($paths))]);
        }
    }

    public static function filterAttachmentUrl($url, $attachmentId)
    {
        return self::toCdnUrl((string)$url);
    }

    public static function filterSrcset($sources)
    {
        if (!is_array($sources)) {
            return $sources;
        }
        foreach ($sources as &$source) {
            if (isset($source['url'])) {
                $source['url'] = self::toCdnUrl((string)$source['url']);
            }
        }
        unset($source);
        return $sources;
    }

    private static function syncAttachment(int $attachmentId)
    {
        $files = self::attachmentFiles($attachmentId);
        if (!$files) {
            return new WP_Error('cdn_drive_no_files', '同期対象ファイルがありません。');
        }
        $errors = [];
        foreach ($files as $file) {
            $result = self::uploadFile($file['local'], $file['remote']);
            if (is_wp_error($result)) {
                $errors[] = $file['remote'] . ': ' . $result->get_error_message();
            }
        }
        if ($errors) {
            return new WP_Error('cdn_drive_sync_failed', implode("\n", $errors));
        }
        return true;
    }

    private static function attachmentFiles(int $attachmentId): array
    {
        $upload = wp_get_upload_dir();
        $baseDir = wp_normalize_path($upload['basedir']);
        $files = [];

        $attached = get_attached_file($attachmentId);
        if ($attached && is_file($attached)) {
            $relative = self::relativeToUploads($attached, $baseDir);
            if ($relative !== '') {
                $files[$relative] = ['local' => $attached, 'remote' => self::remotePath($relative)];
            }
        }

        $metadata = wp_get_attachment_metadata($attachmentId);
        if (is_array($metadata) && !empty($metadata['file'])) {
            $mainRelative = wp_normalize_path((string)$metadata['file']);
            $mainLocal = trailingslashit($baseDir) . $mainRelative;
            if (is_file($mainLocal)) {
                $files[$mainRelative] = ['local' => $mainLocal, 'remote' => self::remotePath($mainRelative)];
            }
            $dir = dirname($mainRelative);
            $dir = $dir === '.' ? '' : $dir . '/';
            if (!empty($metadata['sizes']) && is_array($metadata['sizes'])) {
                foreach ($metadata['sizes'] as $size) {
                    if (empty($size['file'])) {
                        continue;
                    }
                    $relative = $dir . wp_normalize_path((string)$size['file']);
                    $local = trailingslashit($baseDir) . $relative;
                    if (is_file($local)) {
                        $files[$relative] = ['local' => $local, 'remote' => self::remotePath($relative)];
                    }
                }
            }
            if (!empty($metadata['original_image'])) {
                $relative = $dir . wp_normalize_path((string)$metadata['original_image']);
                $local = trailingslashit($baseDir) . $relative;
                if (is_file($local)) {
                    $files[$relative] = ['local' => $local, 'remote' => self::remotePath($relative)];
                }
            }
        }

        return array_values($files);
    }

    private static function uploadFile(string $localPath, string $remotePath)
    {
        if (!function_exists('curl_init') || !function_exists('curl_file_create')) {
            return new WP_Error('cdn_drive_curl_missing', 'PHP cURL が必要です。');
        }
        $options = self::options();
        if ($options['api_base'] === '' || $options['api_token'] === '') {
            return new WP_Error('cdn_drive_not_configured', 'CDN Drive API 設定が不足しています。');
        }
        $ch = curl_init(trailingslashit($options['api_base']) . 'upload');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $options['api_token']],
            CURLOPT_POSTFIELDS => [
                'path' => $remotePath,
                'file' => curl_file_create($localPath, mime_content_type($localPath) ?: 'application/octet-stream', basename($localPath)),
            ],
        ]);
        $response = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false) {
            return new WP_Error('cdn_drive_http_error', $error ?: 'Upload request failed.');
        }
        $data = json_decode((string)$response, true);
        if ($status < 200 || $status >= 300 || !is_array($data) || empty($data['ok'])) {
            $message = is_array($data) && isset($data['error']) ? (string)$data['error'] : (string)$response;
            return new WP_Error('cdn_drive_upload_failed', 'HTTP ' . $status . ': ' . $message);
        }
        return true;
    }

    private static function requestJson(string $path, array $payload)
    {
        $options = self::options();
        if ($options['api_base'] === '' || $options['api_token'] === '') {
            return new WP_Error('cdn_drive_not_configured', 'CDN Drive API 設定が不足しています。');
        }
        $response = wp_remote_post(trailingslashit($options['api_base']) . ltrim($path, '/'), [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $options['api_token'],
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($response)) {
            return $response;
        }
        $status = (int)wp_remote_retrieve_response_code($response);
        $body = (string)wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($status < 200 || $status >= 300 || !is_array($data) || empty($data['ok'])) {
            $message = is_array($data) && isset($data['error']) ? (string)$data['error'] : $body;
            return new WP_Error('cdn_drive_request_failed', 'HTTP ' . $status . ': ' . $message);
        }
        return $data;
    }

    private static function toCdnUrl(string $url): string
    {
        $options = self::options();
        if ($options['replace_urls'] !== '1' || $options['cdn_base_url'] === '') {
            return $url;
        }
        $upload = wp_get_upload_dir();
        $baseUrl = trailingslashit((string)$upload['baseurl']);
        if (!str_starts_with($url, $baseUrl)) {
            return $url;
        }
        $relative = ltrim(substr($url, strlen($baseUrl)), '/');
        if ($relative === '') {
            return $url;
        }
        return trailingslashit($options['cdn_base_url']) . self::remotePath($relative);
    }

    private static function relativeToUploads(string $file, string $baseDir): string
    {
        $file = wp_normalize_path($file);
        $baseDir = trailingslashit(wp_normalize_path($baseDir));
        if (!str_starts_with($file, $baseDir)) {
            return '';
        }
        return ltrim(substr($file, strlen($baseDir)), '/');
    }

    private static function remotePath(string $relative): string
    {
        return trim(self::options()['path_prefix'], '/') . '/' . ltrim(wp_normalize_path($relative), '/');
    }

    private static function cleanPrefix(string $prefix): string
    {
        $prefix = trim(str_replace('\\', '/', $prefix), '/');
        $prefix = preg_replace('#/+#', '/', $prefix) ?: 'wp';
        $prefix = preg_replace('/[^A-Za-z0-9._\/-]/', '-', $prefix) ?: 'wp';
        return trim($prefix, '/') ?: 'wp';
    }

    private static function options(): array
    {
        return array_merge(self::defaults(), (array)get_option(self::OPTION, []));
    }

    private static function defaults(): array
    {
        return [
            'api_base' => '',
            'api_token' => '',
            'cdn_base_url' => '',
            'path_prefix' => 'wp',
            'replace_urls' => '1',
            'auto_sync' => '1',
        ];
    }
}

CDN_Drive_Sync::boot();
